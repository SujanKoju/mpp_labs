package prob1;

/**
 * @author kojusujan1111@gmail.com 24/11/21
 */

public abstract class Property {
    protected Address address;

    abstract double calculateRent();
}
