package ui;

public interface LibWindow {
	void init();
	boolean isInitialized();
	void isInitialized(boolean val);
}
